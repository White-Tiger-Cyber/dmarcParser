
# dmarcParser (dP)

Early scaffold with working discovery, dry-run, ignore rules, and de-dup by XML hash.
This is a prototype for iterating on the full parser/analytics.

## Quick start
```bash
python -m dmarcparser.cli /path/to/DMARC --client acme --dry-run
```
or after install:
```bash
dP /path/DMARC --client acme --dry-run
```
