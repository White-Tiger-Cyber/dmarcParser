
import os, argparse, sys
from rich.console import Console
from rich.table import Table
from . import ingest

def main(argv=None):
    argv = argv or sys.argv[1:]
    ap = argparse.ArgumentParser(prog="dP", description="DMARC Parser (scaffold)")
    ap.add_argument("path", help="File or directory to process")
    ap.add_argument("--client", help="Client key (enables per-client DB & incremental folder runs)")
    ap.add_argument("--state-db", help="Override path to client DB")
    ap.add_argument("--dry-run", action="store_true", help="Do not write DB; just show what would parse/skip")
    ap.add_argument("--rescan", action="store_true", help="Ignore file mtime/size cache and re-check contents")
    args = ap.parse_args(argv)

    path = os.path.abspath(args.path)
    if not os.path.exists(path):
        print(f"Path not found: {path}", file=sys.stderr)
        sys.exit(2)

    client_key = args.client or "adhoc"
    if args.state-db:
        db_path = os.path.abspath(args.state-db)
    else:
        base = os.path.expanduser("~/.dmarcParser/clients")
        os.makedirs(base, exist_ok=True)
        db_path = os.path.join(base, f"{client_key}.db")

    console = Console()
    console.print(f"[bold]Client:[/bold] {client_key}   [bold]DB:[/bold] {db_path}")
    if os.path.isdir(path) and args.client is None:
        console.print("[yellow]Tip:[/yellow] For incremental folder runs, pass --client <key> to enable skip-on-reparse.")

    result = ingest.ingest(path, db_path, client_key, rescan=args.rescan, dry_run=args.dry_run)
    summary = result["summary"]
    # Pretty print summary
    table = Table(title="INGEST SUMMARY")
    table.add_column("Decision")
    table.add_column("Count", justify="right")
    for k in sorted(summary.keys()):
        table.add_row(k, str(summary[k]))
    console.print(table)

    return 0

if __name__ == "__main__":
    raise SystemExit(main())
