
from rich.console import Console

def run_repl(conn, session_info):
    console = Console()
    console.print("[bold]dmarcParser REPL[/bold] (early scaffold) — commands: help, ingest-report, exit")
    while True:
        try:
            cmd = input("dP> ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            return
        if cmd in ("exit","quit"):
            return
        elif cmd == "help":
            console.print("Commands:\n  help\n  ingest-report\n  exit")
        elif cmd == "ingest-report":
            console.print("Use CLI-stage printed summary for now. (Full view coming soon)")
        else:
            console.print(f"Unknown command: {cmd}")
